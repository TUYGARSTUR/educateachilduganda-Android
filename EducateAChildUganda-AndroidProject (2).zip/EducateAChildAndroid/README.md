# Educate a Child Uganda — Android APK

This Android project packages the supplied `index.html` website into a native Android WebView app.

## Build
Open this folder in Android Studio, let Gradle sync, then use **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

The generated debug APK will be under `app/build/outputs/apk/debug/`.

## Important
The supplied website uses Cloudinary, Google Fonts, Font Awesome and Firebase URLs, so the app needs internet access for those remote resources. The Firebase configuration in the supplied HTML is still placeholder configuration and must be replaced with the real Firebase project values before the Administrator dashboard can authenticate/upload content.
